# مشروع تطبيق أندرويد الأصلي بلغة كوتلن (Kotlin)
تطبيق احتساب مستحق الأرشفة الذكي
تصميم وتطوير: سامي القادري 777484160

## كيفية تشغيل المشروع وتوليد ملف APK:
1. افتح برنامج Android Studio.
2. اختر "Open an Existing Project" وحدد هذا المجلد.
3. اضغط من القائمة العلوية على: Build -> Build Bundle(s) / APK(s) -> Build APK(s).
4. سيتولد ملف APK الأصلي فوراً في مسار:
   app/build/outputs/apk/debug/app-debug.apk
